% The code is running by using Matlab 2019
% If you use this code please cite this paper
% Dan Si, Bin Gao, Wei Guo, Yan Yan, G.Y. Tian, Ying Yin ��Variational Mode Decomposition Linked Wavelet Method for EMAT Denoise with Large Lift-off Effect�� 
% NDT & E International, 2019.
% Copyright 2019  Bin Gao
% This software is distributed under the terms of the GNU Public License
% version 3 (http://www.gnu.org/licenses/gpl.txt)
% Report bugs to Bin Gao
% bin_gao -at- uestc.edu.cn
% Checked 24/07/2019
%% load EMAT demo data
clear all;
close all;
clc;
addpath ./vmd_and_others
load('Fe_lift_off/Fe_lift_off_signal.mat')
load('Fe_lift_off/x_time.mat')
lift_off=Fe_lift_off_signal;
%% number of vmd component
K = 2;
%% wavelet denoising setting----
lev=5;
wname = 'db3';
%% remove the baseline
N = length(lift_off);
lambda = 1000;%1000
I = speye(N);
D2 = spdiags(ones(N-2,1)*[1 -2 1],[0 1 2],N-2,N);
trend = inv(I+lambda^2*D2'*D2)*lift_off ;
lift_off=lift_off-trend;
figure;
plot(x_time,lift_off);
xlabel('Times(s)')
ylabel('Amplitude(V)');
axis tight;
%% VMD parameter setting
% Time Domain 0 to T
T = N;
fs = 1/T;
t = (1:T)/T;
freqs = 2*pi*(t-0.5-1/T)/(fs);
fsub = {};
wsub = {};
f=lift_off;
wn=f;
Pxx=10*log10(abs(fft(wn).^2)/N);f_t=(0:length(Pxx)-1)/length(Pxx);
figure;plot(f_t,Pxx);xlabel('Frequency');ylabel('Magnitude��dB��');title('Periodgram N=256');
f_hat = fftshift((fft(f)));
alpha = 2000;        % moderate bandwidth constraint
tau = 0;            % noise-tolerance (no strict fidelity enforcement)            % 3 modes
DC = 0;             % no DC part imposed
init = 1;           % initialize omegas uniformly
tol = 1e-7;

%% vmd decomposition
[u, u_hat, omega] = VMD(f, alpha, tau, K, DC, init, tol);
% For convenience here: Order omegas increasingly and reindex u/u_hat
[~, sortIndex] = sort(omega(end,:));
omega = omega(:,sortIndex);
u_hat = u_hat(:,sortIndex);
u = u(sortIndex,:);
linestyles = {'b', 'g', 'm', 'c', 'c', 'r', 'k'};
figure('Name', 'Composite input signal' );
plot(t,f, 'k');
set(gca, 'XLim', [0 1]);

for sub = 1:length(fsub)
    figure('Name', ['Input signal component ' num2str(sub)] );
    plot(t,fsub{sub}, 'k');
    set(gca, 'XLim', [0 1]);
end

figure('Name', 'Input signal spectrum' );
loglog(freqs(T/2+1:end), abs(f_hat(T/2+1:end)), 'k');
set(gca, 'XLim', [1 T/2]*pi*2, 'XGrid', 'on', 'YGrid', 'on', 'XMinorGrid', 'off', 'YMinorGrid', 'off');
ylims = get(gca, 'YLim');
hold on;
for sub = 1:length(wsub)
    loglog([wsub{sub} wsub{sub}], ylims, 'k--');
end
set(gca, 'YLim', ylims);

figure('Name', 'Evolution of center frequencies omega');
for k=1:K
    semilogx(2*pi/fs*omega(:,k), 1:size(omega,1), linestyles{k});
    hold on;
end
set(gca, 'YLim', [1,size(omega,1)]);
set(gca, 'XLim', [2*pi,0.5*2*pi/fs], 'XGrid', 'on', 'XMinorGrid', 'on');

figure('Name', 'Spectral decomposition');
loglog(freqs(T/2+1:end), abs(f_hat(T/2+1:end)), 'k:');
set(gca, 'XLim', [1 T/2]*pi*2, 'XGrid', 'on', 'YGrid', 'on', 'XMinorGrid', 'off', 'YMinorGrid', 'off');
hold on;
for k = 1:K
    loglog(freqs(T/2+1:end), abs(u_hat(T/2+1:end,k)), linestyles{k});
end
set(gca, 'YLim', ylims);

for k = 1:K
    figure('Name', ['Reconstructed mode ' num2str(K)]);
    plot(t,u(k,:), linestyles{k});  xlabel('Times(s)');
    ylabel('Amplitude(V)'); hold on;
    
    if ~isempty(fsub)
        plot(t, fsub{min(k,length(fsub))}, 'k:');
    end
    %     set(gca, 'XLim', [0 1]);
end
%% kurtosis caculation
for k=1:K
    %     variance(1,k)=var(u(k,:));
    ku(1,k)= kurtosis(u(k,:));
    
end
figure;
bar(ku);ylabel('kurtosis');xlabel('IMF');

%%-----------
for i=1:K
    [pe hist c] = pec(u(i,:),5,1);
    pe_result(1,i)=pe/log(N-5+1);
    %  pe_result(1,i)=pe;
end
figure;
bar(pe_result);title('entropy')

for i=1:K
    result(1,i)=ku(1,i)/ pe_result(1,i);
end
figure;
bar(result);title('adaptive')
max1=max(result);


%% wavelete denoising comparison
denosing=u(1,:);
[dnsig1,c1,l1] = wden(denosing,'rigrsure','h','mln',lev,wname);
figure;
plot(x_time,dnsig1); xlabel('Times(s)');
ylabel('Amplitude(V)');
title('rigrsure denosing');
[dnsig2,c2,l2] = wden(denosing,'minimaxi','h','mln',lev,wname);
figure;
plot(x_time,dnsig2);xlabel('Times(s)');
ylabel('Amplitude(V)')
title('minimaxi denosing')
[dnsig3,c3,l3] = wden(denosing,'sqtwolog','h','mln',lev,wname);
axis tight;
figure;
plot(x_time,dnsig3,'b'); xlabel('Times(s)');
ylabel('Amplitude(V)')
axis tight;
[ output_wavelet ] = EMAT_Wavelet( x_time',denosing );
[dnsig3,c3,l3] = wden(u(1,:),'sqtwolog','h','mln',lev,wname);
%% envelop caculation
finally_signal=dnsig3;
fs=1/(x_time(2)-x_time(1));
n=0:N-1;
t=n/fs;
y_temp = hilbert(finally_signal);
xr2=real(y_temp);
xi2=imag(y_temp);
y_hilbert = sqrt(xr2.^2+xi2.^2);
figure;
plot(t,y_hilbert);title('Hilbert Transform');
y_value=y_hilbert;
% finding peaks
Average_max_min_y_value = (max(y_value)+min(y_value))/2;
S_MinPeakHeight=Average_max_min_y_value-0.7*(max(y_value) -Average_max_min_y_value);
MinPeakDistance=0.15*x_time(end);
[Rwave_y_value,Rwave_x_time] = findpeaks(y_value,x_time,'minpeakheight',S_MinPeakHeight,'MinPeakDistance',MinPeakDistance);
figure;
hold on
plot(x_time,y_value,'b');
plot(Rwave_x_time,Rwave_y_value,'rv','MarkerFaceColor','r');
grid on;
legend('EMAT Signal','Peaks');
xlabel('Time(s)'); ylabel('Amplitude(V)');
title('EMAT�źŷ�ֵ��ȡ����');
%% depth caculation
%     Same_Rwave_Peak_time_1th;
Average_Distance_S=(Rwave_x_time(2)-Rwave_x_time(1))* 3184/2;
%     Average_Distance_S  =  Same_Rwave_Peak_time_1th * 3184/2;


