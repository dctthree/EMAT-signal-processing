function E=Enveloping_entropy(x)
% K=size(x,1);
N=size(x,2);

% for j=1:K
%%ϣ�����ر� 
y_temp = hilbert(x);
xr2=real(y_temp);
xi2=imag(y_temp);
y_hilbert = sqrt(xr2.^2+xi2.^2);


total=sum(y_hilbert);
for i=1:N
   P(1,i)=y_hilbert(1,i)/total;
   
end
E=0;
for i=1:N
    E=E-(P(1,i)*log2(P(1,i)));

end

% E_array(1,j)=E;


% end
% E_array_min=min(E_array);
end

