function [ output_wavelet ] = EMAT_Wavelet( x_time,y_value )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
    s=y_value;
    x=x_time;
    lev=5;
    wname='db3';[c,l]=wavedec(s',lev,wname);
    sigma=wnoisest(c,l,1);
    alpha=2;
    thr1=wbmpen(c,l,sigma,alpha);
    [thr2,nkeep]= wdcbm(c,l,alpha);
    
    xd1=wdencmp('gbl',c,l,wname,lev,thr1,'s',1);
    [xd2,cxd,lxd,perf0,perfl2]=wdencmp('lvd',c,l,wname,lev,thr2,'h');
    [thr,sorh,keepapp]=ddencmp('den','wv',x)
    xd3=wdencmp('gbl',c,l,wname,lev,thr,'s',1);
%     figure();plot(x_time,s);xlabel('Time/s');ylabel('Voltage(V)');title('ԭʼ�ź�','fontsize',12);
    figure();plot(x_time,xd1);xlabel('Time/s');ylabel('Voltage(V)');
    %title('ʹ��penalty��ֵ������ź�','fontsize',12);
%     figure();
    figure;plot(x_time,xd2);xlabel('Time/s');ylabel('Voltage(V)');
    %title('ʹ��Birge-Massart��ֵ������ź�','fontsize',12);
%     figure();
    figure;plot(x_time,xd3);xlabel('Time/s');ylabel('Voltage(V)');
    %title('ʹ��ȱʡ��ֵ������ź�','fontsize',12);
    output_wavelet(1,:)= xd1;
    output_wavelet(2,:)= xd2;
    output_wavelet(3,:)= xd3;
end

