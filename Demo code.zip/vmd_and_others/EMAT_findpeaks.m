function [ Rwave_time,locs_Rwave] = EMAT_findpeaks( x_time,y_value,S_MinPeakHeight, MinPeakDistance)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

%%ԭ���ĺ�������[ Rwave_time,locs_Rwave,Swave_time,locs_Swave] = EMAT_findpeaks( x_time,y_value,S_MinPeakHeight,X_MinPeakHeight, MinPeakDistance)
        %%%%%%%%%%%��ȡ��ֵʱ��%%%%%%%%%%%%%%%%%%
        ECG_data=y_value;%�����ź�
        t=x_time; 
        %[~,locs_Rwave] = findpeaks(ECG_data,'MinPeakHeight',0.5,...
        %                             'MinPeakDistance',1*10^(3));
        [Rwave_time,locs_Rwave] = findpeaks(ECG_data,t,'MinPeakHeight',S_MinPeakHeight,...
                                    'MinPeakDistance',MinPeakDistance);
%         ECG_inverted = -ECG_data;
%         % [~,locs_Swave] = findpeaks(ECG_inverted,'MinPeakHeight',0.5,...
%         %                                 'MinPeakDistance',1*10^(3));
%         [Swave_time,locs_Swave] = findpeaks(ECG_inverted,t,'MinPeakHeight',X_MinPeakHeight,...
%                                     'MinPeakDistance',MinPeakDistance);
%         figure;
%         hold on
%         plot(x_time,y_value);
%         plot(locs_Rwave,Rwave_time,'rv','MarkerFaceColor','r');
%         plot(locs_Swave,-Swave_time,'rs','MarkerFaceColor','b');
%         grid on;
%         legend('ECG Signal','R-waves','S-waves');
%         xlabel('Samples'); ylabel('Voltage(V)')
%         title('R-wave and S-wave in Noisy ECG Signal')

end
