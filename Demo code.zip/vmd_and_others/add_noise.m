function noise_sianle=add_noise(orignial_signal,noise)

SNR_db=noise;
no=std(orignial_signal)*10^(-SNR_db/20)*randn(size(orignial_signal));
noise_sianle=orignial_signal+no;



end